<?php 
include "db.php";
session_start();



$title = $body = $user_id = $important = $assigner = "";

		
// Check if the user is already logged in, if yes then redirect him to welcome page

// Include config file

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
   }
   


$userid = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id=" . $userid;
$res = mysqli_query($con, $query);
 while ($row = mysqli_fetch_assoc($res)) {
	 $user_username = $row['username'];
	 $creator = $row['name'];
	 $user_image = $row['image'];
	
 }

 global $con;
$query = "SELECT * FROM users";
$result = mysqli_query($con, $query);
$users_count = mysqli_num_rows($result);



		
		// get the values from the assgin task form
if($_SERVER["REQUEST_METHOD"] == "POST"){
        
        $title = test_input($_POST['task']);
		$body = test_input($_POST['body']);
		$user_id = test_input($_POST['uid']);
		$important = test_input($_POST['important']);
		$assigner = $userid;

$query = "SELECT id, name FROM users WHERE id=" . $user_id;
$res = mysqli_query($con, $query);
 while ($row = mysqli_fetch_assoc($res)) {
	 $assinged_id = $row['id'];
	 $assinged_name = $row['name'];
	
 }
 
        // Prepare an insert statement
		
        $sql = "INSERT INTO todo (title, body, user_id, important, assigner_id) VALUES (?, ?, ?, ?, ?)";
		
         
        if($stmt = mysqli_prepare($con, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssisi", $param_title, $param_body, $param_uid, $param_important, $param_creatorid);
            // Set parameters
            $param_title = $title;
			$param_body = $body;
			$param_uid = $user_id;
			$param_important = $important;
			$param_creatorid = $assigner;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
				
            
            // ---------------------------------------------
			// push new notification title new_device  
			// ---------------------------------------------
			//next update give him link to that device
			
			$notifications_content = 'You assigned Task For: ' . $assinged_name;            
            $notifications_reciver_id = $userid;
			$notifications_title = "task_assigned";
			
        $myquery = "INSERT INTO notifications (content, reciver_id, title) VALUES('$notifications_content','$notifications_reciver_id','$notifications_title')";
        $myresult = mysqli_query($con, $myquery);

        if (!$myresult) {
			
			// if can't add notifiction show error
          die("Could not send data " . mysqli_error($con));
        }
        else{
			// if notification created and mysqli_stmt_execute($stmt) added device redirect to workstation page 
            //echo "submited";
		    header("location: ../index.php");
        }

// end push
                
			  
            } else{

				echo mysqli_error($con) . "don't forget about notification errors";
				
				//echo "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }

    
    // Close connection
    mysqli_close($con);
} else {
	

}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading" style="background-color:crimson;color:white;
                text-align: center;">Assign Task</div>
				<div class="panel-body">
				
				
        <form  action="asgin_task_form.php" method="post" role="form" enctype="multipart/form-data">
		  <fieldset>	  
            <div class="form-group">
                <label>Task Title</label>
                <input type="text" name="task" class="form-control" value="<?php $title ?>" required="required">
            </div> 

			
            <div class="form-group">
                <label>Body</label>
				<textarea name="body" class="form-control"><?php echo $body; ?></textarea>
            </div>
			
			<!-- users list -->
			
			<div class="form-group">
				<label>Select User (<?php echo $users_count; ?>)</label>
				<select class="form-control" name="uid" required="required">
		<?php 

		        // suppliers part


				

                if(mysqli_num_rows($result) < 1) {
	              // No rows found 
                  echo "<option value='undefined'>undefined</option>";
	              return;
} 
	              // we found the rows
	              while ($row = mysqli_fetch_assoc($result)) {
		
		            $getuid = $row['id'];
		            $getuname = $row['name'];
		 
		            echo "<option value='" . $getuid . "'>" . $getuname ." (" . $getuid . ")" . "</option>";

	}
?>

										</select>
									</div>
									
									<br /><br />
								
			<div class="form-check">Important ?
			<br><br>
               <input class="form-check-input" type="radio" name="important" id="important1" value="y">
               <label class="form-check-label" for="important">
               Yes
               </label>			
			</div>

			<div class="form-check">
              <input class="form-check-input" type="radio" name="important" id="important2" value="n" checked="">
              <label class="form-check-label" for="important">
              No
              </label>
            </div>  

	   
	
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a href="../index.php"><input type="button" class="btn btn-default" value="Cancel"></a>
            </div>
			


	      </fieldset>
        </form>
    </div>    
				</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
</body>
</html>

