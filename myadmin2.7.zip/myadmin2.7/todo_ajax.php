
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myadmin1";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}



$userid = $_SESSION['id'];

 
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
   }

if (isset($_GET['que'])) {
$task_id = $_GET['que'] + 0;




$sql = "UPDATE `todo` SET `finished`=1 WHERE id=".$task_id;


if (mysqli_query($conn, $sql)) {


// New Code Start
	 
	 $sql = "SELECT * FROM todo WHERE id=" . $task_id ;
	 $res_data = mysqli_query($conn,$sql);    
     while($row = mysqli_fetch_array($res_data)){
	     $t_id = $row['id'];
		 $t_title = $row['title'];
		 $t_body = $row['body'];
		 $t_doer = $row['user_id'];
		 $t_assigner = $row['assigner_id'];
		 $t_comment = $row['note'];
		 
	 }
	 
	 $sql = "SELECT * FROM users WHERE id=" . $t_doer ;
	 $res_data = mysqli_query($conn,$sql);    
     while($row = mysqli_fetch_array($res_data)){
		 $doer_name = $row['name'];		 
	 }


	 
	 	 

	$sql = "INSERT INTO task_archive (task_id, task_title, user_id, task_body, task_assigner, note) VALUES (?, ?, ?, ?, ?, ?)";
	if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "isisis", $param_taskid, $param_title, $param_uid, $param_body, $param_asigner, $param_comment);
			
			$param_taskid = $task_id;
			$param_title = $t_title;
			$param_uid = $t_doer;
			$param_body = $t_body;
			$param_asigner = $t_assigner;
			$param_comment = $t_comment;

			
			if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
				
            
            // ---------------------------------------------
			// push new notification title new_device  
			// ---------------------------------------------
			//next update give him link to that device
			
			$notifications_content = $doer_name . " Finished Task ID: " . $task_id;          
            $notifications_reciver_id = $t_assigner;
			$notifications_title = "user_finished_task";
			
        $myquery = "INSERT INTO notifications (content, reciver_id, title) VALUES('$notifications_content','$notifications_reciver_id','$notifications_title')";
        $myresult = mysqli_query($conn, $myquery);
			}
			

	} else {
  echo "Error updating record: " . mysqli_error($conn);
}






} 



// New Code Ends	
	 
echo json_encode(array('success' => 1, 'task' => $task_id));

mysqli_close($conn);



}







?>