<?php 
include "db.php";
session_start();




		
// Check if the user is already logged in, if yes then redirect him to welcome page

// Include config file

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
   }
   


$userid = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id=" . $userid;
$res = mysqli_query($con, $query);
 while ($row = mysqli_fetch_assoc($res)) {
	 $user_username = $row['username'];
	 $creator = $row['name'];
	 $user_image = $row['image'];
	
 }

 global $con;
$query = "SELECT * FROM users";
$result = mysqli_query($con, $query);
$users_count = mysqli_num_rows($result);

$task_id = $_GET['task'];
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading" style="background-color:crimson;color:white;
                text-align: center;">Assign Task</div>
				<div class="panel-body">
				
				
        <form  action="submit_comment_task.php" method="POST" role="form" enctype="multipart/form-data">
		  <fieldset>	  

			
            <div class="form-group">
                <label>Comment</label>

				<textarea name="notes" class="form-control"></textarea>
				
				<!-- this hidden input used to send the task id in the form in order to update the target task -->
				<input type="number" name="why" value="<?php echo $task_id; ?>" style="display:none;">
            </div>
			

	   
	
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a href="../index.php"><input type="button" class="btn btn-default" value="Cancel"></a>
            </div>
			


	      </fieldset>
        </form>
    </div>    
				</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
</body>
</html>







